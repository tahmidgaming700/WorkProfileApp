package com.example.enroller;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = new Intent("android.app.action.PROVISION_MANAGED_PROFILE");
        intent.putExtra("android.app.extra.PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME",
                "com.google.android.apps.work.clouddpc/.receivers.CloudDeviceAdminReceiver");
        intent.putExtra("android.app.extra.PROVISIONING_DEVICE_ADMIN_PACKAGE_DOWNLOAD_LOCATION",
                "https://play.google.com/managed/downloadManagingApp?identifier=setup");
        intent.putExtra("android.app.extra.PROVISIONING_DEVICE_ADMIN_SIGNATURE_CHECKSUM",
                "I5YvS0O5hXY46mb01BlRjq4oJJGs2kuUcHvVkAPEXlg");
        intent.putExtra("android.app.extra.PROVISIONING_MODE", "WORK_PROFILE");
        intent.putExtra("com.google.android.apps.work.clouddpc.EXTRA_ENROLLMENT_TOKEN",
                "XAIBXONNGYFGZYSJABZV");

        startActivity(intent);
        finish();
    }
}
